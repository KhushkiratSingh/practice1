package com.cegep.saporiitaliano.model;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class Category {

    public String key;

    public String name;
}