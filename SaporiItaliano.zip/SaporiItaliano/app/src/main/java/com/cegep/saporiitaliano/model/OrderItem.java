package com.cegep.saporiitaliano.model;

public class OrderItem {

    public String id;

    public String imageUri;

    public String name;

    public long price;

    public long quantity;

    public long sum;

}
