package com.cegep.saporiitaliano.common;

public interface OnItemClickListener<T> {

    void onItemClick(T item, int position);

}
